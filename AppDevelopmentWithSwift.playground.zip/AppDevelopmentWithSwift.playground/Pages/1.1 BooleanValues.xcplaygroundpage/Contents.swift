let number = 1000
let smallNumber = number < 10

let speedLimit = 65
let currentSpeed = 72
let isSpeeding = currentSpeed > speedLimit

var isSnowing = false
if !isSnowing {
    print("it is not snowing")
}

let temperature = 75
if temperature >= 65 && temperature <= 75 {
    print("aa")
} else if temperature < 65 {
    print("bb")
} else {
    print("cc")
}
var q1 = true
var q2 = false

if q1 || q2 {
    print("q1 q2")
} else {
    print("no")
}

